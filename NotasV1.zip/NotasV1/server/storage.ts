import { users, notes, emailCache, attachments, type User, type InsertUser, type Note, type InsertNote, type EmailCache, type InsertEmailCache, type Attachment, type InsertAttachment } from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, like, or } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByMicrosoftId(microsoftId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;

  // Note operations
  getUserNotes(userId: string): Promise<Note[]>;
  getNote(id: string, userId: string): Promise<Note | undefined>;
  createNote(note: InsertNote): Promise<Note>;
  updateNote(id: string, userId: string, note: Partial<InsertNote>): Promise<Note | undefined>;
  deleteNote(id: string, userId: string): Promise<boolean>;
  searchNotes(userId: string, query: string): Promise<Note[]>;

  // Email cache operations
  getUserEmails(userId: string, folder?: string): Promise<EmailCache[]>;
  getEmail(id: string, userId: string): Promise<EmailCache | undefined>;
  cacheEmail(email: InsertEmailCache): Promise<EmailCache>;
  updateEmail(id: string, userId: string, email: Partial<InsertEmailCache>): Promise<EmailCache | undefined>;
  searchEmails(userId: string, query: string): Promise<EmailCache[]>;

  // Attachment operations
  getAttachments(emailId?: string, noteId?: string): Promise<Attachment[]>;
  createAttachment(attachment: InsertAttachment): Promise<Attachment>;
  getAttachment(id: string, userId: string): Promise<Attachment | undefined>;
  deleteAttachment(id: string, userId: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByMicrosoftId(microsoftId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.microsoftId, microsoftId));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        updatedAt: new Date(),
      })
      .returning();
    return user;
  }

  async updateUser(id: string, updateUser: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({
        ...updateUser,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getUserNotes(userId: string): Promise<Note[]> {
    return db
      .select()
      .from(notes)
      .where(eq(notes.userId, userId))
      .orderBy(desc(notes.updatedAt));
  }

  async getNote(id: string, userId: string): Promise<Note | undefined> {
    const [note] = await db
      .select()
      .from(notes)
      .where(and(eq(notes.id, id), eq(notes.userId, userId)));
    return note || undefined;
  }

  async createNote(insertNote: InsertNote): Promise<Note> {
    const [note] = await db
      .insert(notes)
      .values({
        ...insertNote,
        updatedAt: new Date(),
      })
      .returning();
    return note;
  }

  async updateNote(id: string, userId: string, updateNote: Partial<InsertNote>): Promise<Note | undefined> {
    const [note] = await db
      .update(notes)
      .set({
        ...updateNote,
        updatedAt: new Date(),
      })
      .where(and(eq(notes.id, id), eq(notes.userId, userId)))
      .returning();
    return note || undefined;
  }

  async deleteNote(id: string, userId: string): Promise<boolean> {
    const result = await db
      .delete(notes)
      .where(and(eq(notes.id, id), eq(notes.userId, userId)));
    return result.rowCount > 0;
  }

  async searchNotes(userId: string, query: string): Promise<Note[]> {
    return db
      .select()
      .from(notes)
      .where(
        and(
          eq(notes.userId, userId),
          or(
            like(notes.title, `%${query}%`),
            like(notes.content, `%${query}%`)
          )
        )
      )
      .orderBy(desc(notes.updatedAt));
  }

  async getUserEmails(userId: string, folder?: string): Promise<EmailCache[]> {
    const conditions = [eq(emailCache.userId, userId)];
    if (folder) {
      conditions.push(eq(emailCache.folder, folder));
    }

    return db
      .select()
      .from(emailCache)
      .where(and(...conditions))
      .orderBy(desc(emailCache.receivedAt));
  }

  async getEmail(id: string, userId: string): Promise<EmailCache | undefined> {
    const [email] = await db
      .select()
      .from(emailCache)
      .where(and(eq(emailCache.id, id), eq(emailCache.userId, userId)));
    return email || undefined;
  }

  async cacheEmail(insertEmail: InsertEmailCache): Promise<EmailCache> {
    const [email] = await db
      .insert(emailCache)
      .values(insertEmail)
      .returning();
    return email;
  }

  async updateEmail(id: string, userId: string, updateEmail: Partial<InsertEmailCache>): Promise<EmailCache | undefined> {
    const [email] = await db
      .update(emailCache)
      .set(updateEmail)
      .where(and(eq(emailCache.id, id), eq(emailCache.userId, userId)))
      .returning();
    return email || undefined;
  }

  async searchEmails(userId: string, query: string): Promise<EmailCache[]> {
    return db
      .select()
      .from(emailCache)
      .where(
        and(
          eq(emailCache.userId, userId),
          or(
            like(emailCache.subject, `%${query}%`),
            like(emailCache.body, `%${query}%`),
            like(emailCache.sender, `%${query}%`)
          )
        )
      )
      .orderBy(desc(emailCache.receivedAt));
  }

  async getAttachments(emailId?: string, noteId?: string): Promise<Attachment[]> {
    const conditions = [];
    if (emailId) {
      conditions.push(eq(attachments.emailId, emailId));
    }
    if (noteId) {
      conditions.push(eq(attachments.noteId, noteId));
    }

    return db
      .select()
      .from(attachments)
      .where(and(...conditions))
      .orderBy(desc(attachments.createdAt));
  }

  async createAttachment(insertAttachment: InsertAttachment): Promise<Attachment> {
    const [attachment] = await db
      .insert(attachments)
      .values(insertAttachment)
      .returning();
    return attachment;
  }

  async getAttachment(id: string, userId: string): Promise<Attachment | undefined> {
    const [attachment] = await db
      .select()
      .from(attachments)
      .where(and(eq(attachments.id, id), eq(attachments.userId, userId)));
    return attachment || undefined;
  }

  async deleteAttachment(id: string, userId: string): Promise<boolean> {
    const result = await db
      .delete(attachments)
      .where(and(eq(attachments.id, id), eq(attachments.userId, userId)));
    return result.rowCount > 0;
  }
}

export const storage = new DatabaseStorage();
