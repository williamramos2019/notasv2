import { ConfidentialClientApplication, AuthenticationResult } from "@azure/msal-node";

const isDevelopment = process.env.NODE_ENV === "development";
const hasCredentials = process.env.MICROSOFT_CLIENT_ID && process.env.MICROSOFT_CLIENT_SECRET;

const msalConfig = {
  auth: {
    clientId: process.env.MICROSOFT_CLIENT_ID || "dev-client-id",
    clientSecret: process.env.MICROSOFT_CLIENT_SECRET || "dev-client-secret",
    authority: `https://login.microsoftonline.com/${process.env.MICROSOFT_TENANT_ID || "common"}`,
  },
};

let msalInstance: ConfidentialClientApplication | null = null;

// Only initialize MSAL if we have proper credentials
if (hasCredentials) {
  try {
    msalInstance = new ConfidentialClientApplication(msalConfig);
  } catch (error) {
    console.warn("Failed to initialize Microsoft Auth:", error);
    msalInstance = null;
  }
}

export class MicrosoftAuthService {
  async getAuthUrl(redirectUri: string, state?: string): Promise<string> {
    if (!msalInstance) {
      throw new Error("Microsoft Auth not available - credentials not configured");
    }

    const authUrlParameters = {
      scopes: [
        "openid",
        "profile",
        "email",
        "Mail.Read",
        "Mail.ReadWrite",
        "offline_access"
      ],
      redirectUri,
      state,
    };

    return await msalInstance.getAuthCodeUrl(authUrlParameters);
  }

  async getTokenByCode(code: string, redirectUri: string): Promise<AuthenticationResult> {
    if (!msalInstance) {
      throw new Error("Microsoft Auth not available - credentials not configured");
    }

    const tokenRequest = {
      code,
      scopes: [
        "openid",
        "profile", 
        "email",
        "Mail.Read",
        "Mail.ReadWrite",
        "offline_access"
      ],
      redirectUri,
    };

    return msalInstance.acquireTokenByCode(tokenRequest);
  }

  async refreshToken(refreshToken: string): Promise<AuthenticationResult> {
    if (!msalInstance) {
      throw new Error("Microsoft Auth not available - credentials not configured");
    }

    const refreshRequest = {
      refreshToken,
      scopes: [
        "Mail.Read",
        "Mail.ReadWrite"
      ],
    };

    const result = await msalInstance.acquireTokenByRefreshToken(refreshRequest);
    if (!result) {
      throw new Error("Failed to refresh token");
    }
    return result;
  }

  async validateToken(accessToken: string): Promise<boolean> {
    if (!msalInstance) {
      return false;
    }

    try {
      // Simple validation by making a test request to Graph API
      const response = await fetch("https://graph.microsoft.com/v1.0/me", {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  isAvailable(): boolean {
    return msalInstance !== null;
  }
}

export const microsoftAuthService = new MicrosoftAuthService();
