import { Client } from "@microsoft/microsoft-graph-client";
import { storage } from "../storage";

interface GraphEmail {
  id: string;
  subject: string;
  sender: {
    emailAddress: {
      name: string;
      address: string;
    };
  };
  toRecipients: Array<{
    emailAddress: {
      name: string;
      address: string;
    };
  }>;
  body: {
    content: string;
    contentType: string;
  };
  receivedDateTime: string;
  isRead: boolean;
  hasAttachments: boolean;
  attachments?: Array<{
    id: string;
    name: string;
    size: number;
    contentType: string;
  }>;
}

class MicrosoftGraphService {
  private getClient(accessToken: string): Client {
    return Client.init({
      authProvider: (done) => {
        done(null, accessToken);
      }
    });
  }

  async getUserProfile(accessToken: string) {
    const client = this.getClient(accessToken);
    return await client.api("/me").get();
  }

  async getEmails(accessToken: string, userId: string, folder: string = "inbox"): Promise<any[]> {
    const client = this.getClient(accessToken);
    
    try {
      const emails = await client
        .api(`/me/mailFolders/${folder}/messages`)
        .select('id,subject,sender,toRecipients,body,receivedDateTime,isRead,hasAttachments')
        .top(50)
        .get();

      // Cache emails in database
      for (const email of emails.value) {
        await this.cacheEmail(email, userId);
      }

      return emails.value;
    } catch (error) {
      console.error("Failed to fetch emails:", error);
      throw error;
    }
  }

  async getEmailAttachments(accessToken: string, emailId: string): Promise<any[]> {
    const client = this.getClient(accessToken);
    
    try {
      const attachments = await client
        .api(`/me/messages/${emailId}/attachments`)
        .get();

      return attachments.value;
    } catch (error) {
      console.error("Failed to fetch email attachments:", error);
      throw error;
    }
  }

  async downloadAttachment(accessToken: string, emailId: string, attachmentId: string): Promise<Buffer> {
    const client = this.getClient(accessToken);
    
    try {
      const attachment = await client
        .api(`/me/messages/${emailId}/attachments/${attachmentId}`)
        .get();

      if (attachment['@odata.type'] === '#microsoft.graph.fileAttachment') {
        return Buffer.from(attachment.contentBytes, 'base64');
      }
      
      throw new Error("Unsupported attachment type");
    } catch (error) {
      console.error("Failed to download attachment:", error);
      throw error;
    }
  }

  private async cacheEmail(graphEmail: GraphEmail, userId: string): Promise<void> {
    try {
      const existingEmail = await storage.getEmailsByUserId(userId);
      const emailExists = existingEmail.some(e => e.messageId === graphEmail.id);
      
      if (!emailExists) {
        await storage.createEmail({
          id: graphEmail.id,
          messageId: graphEmail.id,
          subject: graphEmail.subject || "(No Subject)",
          sender: graphEmail.sender?.emailAddress?.name || "Unknown Sender",
          senderEmail: graphEmail.sender?.emailAddress?.address || "",
          recipient: graphEmail.toRecipients?.[0]?.emailAddress?.address || "",
          content: this.extractTextFromHtml(graphEmail.body?.content || ""),
          htmlContent: graphEmail.body?.content || "",
          receivedAt: new Date(graphEmail.receivedDateTime),
          isRead: graphEmail.isRead || false,
          hasAttachments: graphEmail.hasAttachments || false,
          attachments: graphEmail.attachments || [],
          userId,
        });
      }
    } catch (error) {
      console.error("Failed to cache email:", error);
    }
  }

  private extractTextFromHtml(html: string): string {
    // Simple HTML to text conversion
    return html
      .replace(/<[^>]*>/g, '')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .trim();
  }
}

export const microsoftGraphService = new MicrosoftGraphService();
