import { Client } from "@microsoft/microsoft-graph-client";
import { storage } from "../storage";
import type { User } from "@shared/schema";

export class GraphApiService {
  private getClient(accessToken: string): Client {
    return Client.init({
      authProvider: {
        getAccessToken: async () => accessToken,
      },
    });
  }

  async getUserProfile(accessToken: string) {
    const client = this.getClient(accessToken);
    return client.api("/me").get();
  }

  async getEmails(accessToken: string, userId: string, folder: string = "inbox", top: number = 50) {
    const client = this.getClient(accessToken);
    
    try {
      const response = await client
        .api(`/me/mailFolders/${folder}/messages`)
        .top(top)
        .select("id,subject,sender,receivedDateTime,bodyPreview,body,hasAttachments")
        .orderby("receivedDateTime desc")
        .get();

      // Cache emails in database
      for (const email of response.value) {
        await this.cacheEmail(email, userId);
      }

      return response.value;
    } catch (error) {
      console.error("Error fetching emails:", error);
      throw error;
    }
  }

  async getEmailAttachments(accessToken: string, emailId: string) {
    const client = this.getClient(accessToken);
    
    try {
      const response = await client
        .api(`/me/messages/${emailId}/attachments`)
        .get();
      
      return response.value;
    } catch (error) {
      console.error("Error fetching attachments:", error);
      throw error;
    }
  }

  async downloadAttachment(accessToken: string, emailId: string, attachmentId: string) {
    const client = this.getClient(accessToken);
    
    try {
      const attachment = await client
        .api(`/me/messages/${emailId}/attachments/${attachmentId}`)
        .get();
      
      return attachment;
    } catch (error) {
      console.error("Error downloading attachment:", error);
      throw error;
    }
  }

  async searchEmails(accessToken: string, query: string, userId: string) {
    const client = this.getClient(accessToken);
    
    try {
      const response = await client
        .api("/me/messages")
        .search(query)
        .select("id,subject,sender,receivedDateTime,bodyPreview,body,hasAttachments")
        .top(50)
        .get();

      // Cache search results
      for (const email of response.value) {
        await this.cacheEmail(email, userId);
      }

      return response.value;
    } catch (error) {
      console.error("Error searching emails:", error);
      throw error;
    }
  }

  private async cacheEmail(email: any, userId: string) {
    try {
      const emailData = {
        userId,
        emailId: email.id,
        subject: email.subject || "",
        sender: email.sender?.emailAddress?.name || "",
        senderEmail: email.sender?.emailAddress?.address || "",
        body: email.body?.content || email.bodyPreview || "",
        receivedAt: new Date(email.receivedDateTime),
        hasAttachments: email.hasAttachments || false,
        attachments: [],
        isRead: email.isRead || false,
        folder: "inbox",
      };

      // Check if email already exists
      const existingEmails = await storage.getUserEmails(userId);
      const exists = existingEmails.some(e => e.emailId === email.id);
      
      if (!exists) {
        await storage.cacheEmail(emailData);
      }
    } catch (error) {
      console.error("Error caching email:", error);
    }
  }

  async getMailFolders(accessToken: string) {
    const client = this.getClient(accessToken);
    
    try {
      const response = await client
        .api("/me/mailFolders")
        .get();
      
      return response.value;
    } catch (error) {
      console.error("Error fetching mail folders:", error);
      throw error;
    }
  }
}

export const graphApiService = new GraphApiService();
