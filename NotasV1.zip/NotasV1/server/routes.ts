import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { microsoftAuthService } from "./services/microsoft-auth";
import { graphApiService } from "./services/graph-api";
import { insertNoteSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";
import session from "express-session";

// Extend session data type
declare module "express-session" {
  interface SessionData {
    userId?: string;
    oauthState?: string;
  }
}

// Configure multer for file uploads
const upload = multer({
  dest: "uploads/",
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || "your-secret-key-here",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    },
  }));

  // Microsoft OAuth routes
  app.get("/api/auth/microsoft", async (req, res) => {
    try {
      if (!microsoftAuthService.isAvailable()) {
        return res.status(503).json({ 
          message: "Microsoft authentication not available - credentials not configured",
          available: false 
        });
      }

      const redirectUri = `${req.protocol}://${req.get("host")}/api/auth/callback`;
      const state = Math.random().toString(36).substring(7);
      
      // Store state in session for validation
      req.session.oauthState = state;
      
      const authUrl = await microsoftAuthService.getAuthUrl(redirectUri, state);
      res.json({ authUrl, available: true });
    } catch (error) {
      console.error("Error generating auth URL:", error);
      res.status(500).json({ message: "Failed to generate authentication URL" });
    }
  });

  app.get("/api/auth/callback", async (req, res) => {
    try {
      const { code, state } = req.query;
      
      // Validate state parameter
      if (state !== req.session.oauthState) {
        return res.status(400).json({ message: "Invalid state parameter" });
      }
      
      if (!code) {
        return res.status(400).json({ message: "Authorization code not provided" });
      }

      const redirectUri = `${req.protocol}://${req.get("host")}/api/auth/callback`;
      const tokenResponse = await microsoftAuthService.getTokenByCode(code as string, redirectUri);
      
      // Get user profile from Microsoft Graph
      const userProfile = await graphApiService.getUserProfile(tokenResponse.accessToken);
      
      // Check if user exists or create new user
      let user = await storage.getUserByMicrosoftId(userProfile.id);
      
      if (!user) {
        user = await storage.createUser({
          username: userProfile.userPrincipalName || userProfile.mail,
          email: userProfile.mail || userProfile.userPrincipalName,
          displayName: userProfile.displayName,
          microsoftId: userProfile.id,
          accessToken: tokenResponse.accessToken,
          refreshToken: (tokenResponse as any).refresh_token || null,
          tokenExpiry: new Date(Date.now() + (tokenResponse.expiresOn?.getTime() || 3600000)),
        });
      } else {
        // Update tokens
        await storage.updateUser(user.id, {
          accessToken: tokenResponse.accessToken,
          refreshToken: (tokenResponse as any).refresh_token || null,
          tokenExpiry: new Date(Date.now() + (tokenResponse.expiresOn?.getTime() || 3600000)),
        });
      }

      // Store user session
      req.session.userId = user.id;
      
      // Redirect to dashboard
      res.redirect("/dashboard");
    } catch (error) {
      console.error("Authentication callback error:", error);
      res.status(500).json({ message: "Authentication failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  // Development mode - create demo user
  app.post("/api/auth/demo", async (req, res) => {
    try {
      // Create or get demo user for development
      let user = await storage.getUserByMicrosoftId("demo-user");
      
      if (!user) {
        user = await storage.createUser({
          username: "demo@example.com",
          email: "demo@example.com",
          displayName: "Demo User",
          microsoftId: "demo-user",
          accessToken: null,
          refreshToken: null,
          tokenExpiry: null,
        });
      }

      // Store user session
      req.session.userId = user.id;
      
      res.json({ message: "Demo authentication successful", user: {
        id: user.id,
        username: user.username,
        email: user.email,
        displayName: user.displayName
      }});
    } catch (error) {
      console.error("Demo authentication error:", error);
      res.status(500).json({ message: "Demo authentication failed" });
    }
  });

  // Check authentication middleware
  const requireAuth = async (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    
    req.user = user;
    next();
  };

  // Current user route
  app.get("/api/user", requireAuth, (req: any, res) => {
    const { accessToken, refreshToken, ...safeUser } = req.user;
    res.json(safeUser);
  });

  // Notes routes
  app.get("/api/notes", requireAuth, async (req: any, res) => {
    try {
      const notes = await storage.getUserNotes(req.user.id);
      res.json(notes);
    } catch (error) {
      console.error("Error fetching notes:", error);
      res.status(500).json({ message: "Failed to fetch notes" });
    }
  });

  app.get("/api/notes/:id", requireAuth, async (req: any, res) => {
    try {
      const note = await storage.getNote(req.params.id, req.user.id);
      if (!note) {
        return res.status(404).json({ message: "Note not found" });
      }
      res.json(note);
    } catch (error) {
      console.error("Error fetching note:", error);
      res.status(500).json({ message: "Failed to fetch note" });
    }
  });

  app.post("/api/notes", requireAuth, async (req: any, res) => {
    try {
      const noteData = insertNoteSchema.parse({ ...req.body, userId: req.user.id });
      const note = await storage.createNote(noteData);
      res.status(201).json(note);
    } catch (error) {
      console.error("Error creating note:", error);
      res.status(500).json({ message: "Failed to create note" });
    }
  });

  app.put("/api/notes/:id", requireAuth, async (req: any, res) => {
    try {
      const note = await storage.updateNote(req.params.id, req.user.id, req.body);
      if (!note) {
        return res.status(404).json({ message: "Note not found" });
      }
      res.json(note);
    } catch (error) {
      console.error("Error updating note:", error);
      res.status(500).json({ message: "Failed to update note" });
    }
  });

  app.delete("/api/notes/:id", requireAuth, async (req: any, res) => {
    try {
      const deleted = await storage.deleteNote(req.params.id, req.user.id);
      if (!deleted) {
        return res.status(404).json({ message: "Note not found" });
      }
      res.json({ message: "Note deleted successfully" });
    } catch (error) {
      console.error("Error deleting note:", error);
      res.status(500).json({ message: "Failed to delete note" });
    }
  });

  app.get("/api/search", requireAuth, async (req: any, res) => {
    try {
      const { q, type = "all" } = req.query;
      if (!q) {
        return res.status(400).json({ message: "Search query required" });
      }

      const results: any = { notes: [], emails: [] };

      if (type === "all" || type === "notes") {
        results.notes = await storage.searchNotes(req.user.id, q as string);
      }

      if (type === "all" || type === "emails") {
        results.emails = await storage.searchEmails(req.user.id, q as string);
        
        // If user has active token, also search live emails
        if (req.user.accessToken) {
          try {
            await graphApiService.searchEmails(req.user.accessToken, q as string, req.user.id);
            // Refresh cached emails with live results
            results.emails = await storage.searchEmails(req.user.id, q as string);
          } catch (error) {
            console.log("Live email search failed, using cached results");
          }
        }
      }

      res.json(results);
    } catch (error) {
      console.error("Error searching:", error);
      res.status(500).json({ message: "Search failed" });
    }
  });

  // Email routes
  app.get("/api/emails", requireAuth, async (req: any, res) => {
    try {
      const { folder = "inbox", refresh = "false" } = req.query;
      
      if (refresh === "true" && req.user.accessToken) {
        // Fetch fresh emails from Graph API
        await graphApiService.getEmails(req.user.accessToken, req.user.id, folder);
      }
      
      const emails = await storage.getUserEmails(req.user.id, folder);
      res.json(emails);
    } catch (error) {
      console.error("Error fetching emails:", error);
      res.status(500).json({ message: "Failed to fetch emails" });
    }
  });

  app.get("/api/emails/:id", requireAuth, async (req: any, res) => {
    try {
      const email = await storage.getEmail(req.params.id, req.user.id);
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }
      res.json(email);
    } catch (error) {
      console.error("Error fetching email:", error);
      res.status(500).json({ message: "Failed to fetch email" });
    }
  });

  app.get("/api/emails/:id/attachments", requireAuth, async (req: any, res) => {
    try {
      const email = await storage.getEmail(req.params.id, req.user.id);
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }

      if (req.user.accessToken) {
        const attachments = await graphApiService.getEmailAttachments(req.user.accessToken, email.emailId);
        res.json(attachments);
      } else {
        res.status(401).json({ message: "Microsoft authentication required" });
      }
    } catch (error) {
      console.error("Error fetching attachments:", error);
      res.status(500).json({ message: "Failed to fetch attachments" });
    }
  });

  app.get("/api/emails/:id/attachments/:attachmentId/download", requireAuth, async (req: any, res) => {
    try {
      const email = await storage.getEmail(req.params.id, req.user.id);
      if (!email) {
        return res.status(404).json({ message: "Email not found" });
      }

      if (req.user.accessToken) {
        const attachment = await graphApiService.downloadAttachment(
          req.user.accessToken,
          email.emailId,
          req.params.attachmentId
        );

        res.setHeader("Content-Disposition", `attachment; filename="${attachment.name}"`);
        res.setHeader("Content-Type", attachment.contentType || "application/octet-stream");
        
        if (attachment.contentBytes) {
          const buffer = Buffer.from(attachment.contentBytes, "base64");
          res.send(buffer);
        } else {
          res.status(404).json({ message: "Attachment content not available" });
        }
      } else {
        res.status(401).json({ message: "Microsoft authentication required" });
      }
    } catch (error) {
      console.error("Error downloading attachment:", error);
      res.status(500).json({ message: "Failed to download attachment" });
    }
  });

  // File upload for attachments
  app.post("/api/attachments/upload", requireAuth, upload.single("file"), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { noteId } = req.body;
      
      const attachment = await storage.createAttachment({
        userId: req.user.id,
        noteId: noteId || null,
        emailId: null,
        fileName: req.file.filename,
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
        filePath: req.file.path,
      });

      res.status(201).json(attachment);
    } catch (error) {
      console.error("Error uploading attachment:", error);
      res.status(500).json({ message: "Failed to upload attachment" });
    }
  });

  app.get("/api/attachments/:id/download", requireAuth, async (req: any, res) => {
    try {
      const attachment = await storage.getAttachment(req.params.id, req.user.id);
      if (!attachment) {
        return res.status(404).json({ message: "Attachment not found" });
      }

      const filePath = path.resolve(attachment.filePath);
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "File not found on disk" });
      }

      res.setHeader("Content-Disposition", `attachment; filename="${attachment.originalName}"`);
      res.setHeader("Content-Type", attachment.mimeType);
      res.sendFile(filePath);
    } catch (error) {
      console.error("Error downloading attachment:", error);
      res.status(500).json({ message: "Failed to download attachment" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
