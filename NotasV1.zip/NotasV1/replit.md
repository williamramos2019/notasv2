# Overview

NotasV1 is a comprehensive notes and email management application that integrates with Microsoft Graph API to provide seamless access to Outlook emails alongside a powerful note-taking system. The application features Microsoft OAuth 2.0 authentication, real-time email synchronization, rich text editing for notes, and modern responsive UI built with React and TypeScript.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built with React 18 and TypeScript, using Vite as the build tool. The architecture follows modern React patterns with functional components and hooks. Key design decisions include:

- **Component Architecture**: Modular component structure with separate directories for notes, email, layout, and UI components
- **State Management**: React Query (@tanstack/react-query) for server state management and caching, with local state handled by React hooks
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

## Backend Architecture
The backend uses Express.js with TypeScript in ESM mode. Core architectural decisions:

- **API Design**: RESTful API structure with dedicated route handlers for authentication, notes, and email operations
- **Authentication**: Microsoft OAuth 2.0 integration using @azure/msal-node with session-based authentication
- **Session Management**: Express sessions with configurable storage (memory for development, can be extended to PostgreSQL)
- **Service Layer**: Dedicated services for Microsoft Graph API integration and authentication flows
- **File Handling**: Multer middleware for attachment uploads with size limits and security constraints

## Data Storage Solutions
The application uses PostgreSQL as the primary database with Drizzle ORM for type-safe database operations:

- **Database**: Neon PostgreSQL serverless database for production scalability
- **ORM**: Drizzle ORM with zod integration for runtime type validation
- **Schema Management**: Centralized schema definitions in shared directory for type consistency across frontend and backend
- **Migrations**: Drizzle Kit for database migrations and schema synchronization
- **Caching Strategy**: Email caching in database to reduce API calls and improve performance

## Authentication and Authorization
Microsoft-centric authentication system designed for enterprise integration:

- **OAuth Provider**: Microsoft Identity Platform with multi-tenant support
- **Token Management**: Automatic token refresh with secure storage of access and refresh tokens
- **Session Security**: HTTP-only cookies with CSRF protection and configurable security settings
- **Authorization Flow**: Authorization code flow with PKCE for security best practices
- **Scope Management**: Granular permissions for Mail.Read, Mail.ReadWrite, and profile access

# External Dependencies

## Microsoft Services Integration
- **Microsoft Graph API**: Core integration for email access, user profile, and attachment handling
- **Azure AD/Entra ID**: Identity provider for authentication and authorization
- **MSAL Libraries**: @azure/msal-node for backend and @azure/msal-browser for frontend OAuth flows

## Database and ORM
- **Neon Database**: Serverless PostgreSQL database with WebSocket support for real-time features
- **Drizzle ORM**: Type-safe database operations with automatic TypeScript inference
- **Connection Pooling**: @neondatabase/serverless for optimized database connections

## Frontend Dependencies
- **React Ecosystem**: React 18 with TypeScript, React Query for data fetching, React Hook Form for forms
- **UI Components**: Radix UI primitives for accessibility, Tailwind CSS for styling, Lucide React for icons
- **Development Tools**: Vite for fast development builds, ESLint for code quality

## Backend Dependencies
- **Express Framework**: Web server with TypeScript support, middleware for sessions, CORS, and file uploads
- **Authentication**: MSAL Node for Microsoft OAuth, express-session for session management
- **Utilities**: Date-fns for date manipulation, nanoid for ID generation, ws for WebSocket support

## Build and Development Tools
- **TypeScript**: Strict type checking across the entire application
- **ESBuild**: Fast bundling for production builds
- **Path Mapping**: Configured aliases for clean imports (@/, @shared/, @assets/)
- **Development Server**: Vite dev server with HMR and runtime error handling for Replit environment