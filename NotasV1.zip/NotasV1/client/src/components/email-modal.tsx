import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { formatDistanceToNow, format } from "date-fns";
import { 
  X, 
  RefreshCw, 
  Paperclip, 
  Reply, 
  Forward, 
  Archive, 
  Download, 
  Eye, 
  Save,
  Mail
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useEmails, useEmailAttachments, useDownloadAttachment } from "@/hooks/use-emails";
import { useToast } from "@/hooks/use-toast";
import type { EmailCache } from "@shared/schema";

interface EmailModalProps {
  isOpen: boolean;
  onClose: () => void;
  "data-testid"?: string;
}

export default function EmailModal({ isOpen, onClose, ...props }: EmailModalProps) {
  const [selectedEmail, setSelectedEmail] = useState<EmailCache | null>(null);
  const { emails, refreshEmails, isRefreshing } = useEmails("inbox");
  const { attachments, isLoading: attachmentsLoading } = useEmailAttachments(selectedEmail?.id || "");
  const { downloadAttachment, isDownloading } = useDownloadAttachment();
  const { toast } = useToast();

  const handleSelectEmail = (email: EmailCache) => {
    setSelectedEmail(email);
  };

  const handleCloseModal = () => {
    setSelectedEmail(null);
    onClose();
  };

  const getInitials = (name: string) => {
    if (!name) return "?";
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };

  const getAvatarColor = (email: string) => {
    // Simple hash function to get consistent colors
    let hash = 0;
    for (let i = 0; i < email.length; i++) {
      hash = email.charCodeAt(i) + ((hash << 5) - hash);
    }
    const colors = [
      "bg-red-500", "bg-blue-500", "bg-green-500", "bg-yellow-500", 
      "bg-purple-500", "bg-pink-500", "bg-indigo-500", "bg-orange-500"
    ];
    return colors[Math.abs(hash) % colors.length];
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType?.includes("pdf")) return "fas fa-file-pdf text-red-600";
    if (mimeType?.includes("excel") || mimeType?.includes("sheet")) return "fas fa-file-excel text-green-600";
    if (mimeType?.includes("word") || mimeType?.includes("document")) return "fas fa-file-word text-blue-600";
    if (mimeType?.includes("image")) return "fas fa-file-image text-purple-600";
    return "fas fa-file text-gray-600";
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const handleDownload = (attachmentId: string) => {
    if (selectedEmail) {
      downloadAttachment({ emailId: selectedEmail.id, attachmentId });
    }
  };

  const handleSaveAttachment = (attachmentId: string) => {
    toast({ 
      title: "Feature Coming Soon", 
      description: "Save to notes system will be available soon!" 
    });
  };

  const handlePreviewAttachment = (attachmentId: string) => {
    toast({ 
      title: "Feature Coming Soon", 
      description: "Attachment preview will be available soon!" 
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleCloseModal} {...props}>
      <DialogContent className="max-w-7xl max-h-[90vh] p-0">
        <DialogHeader className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-semibold">
              Microsoft Outlook - Inbox
            </DialogTitle>
            <div className="flex items-center space-x-2">
              <Badge variant="secondary" className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 border-green-200 dark:border-green-800">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                Connected to Microsoft Graph
              </Badge>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => refreshEmails()}
                disabled={isRefreshing}
                data-testid="button-refresh-emails"
              >
                <RefreshCw className={cn("h-4 w-4", isRefreshing && "animate-spin")} />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleCloseModal}
                data-testid="button-close-email-modal"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>
        
        <div className="flex flex-1 overflow-hidden">
          {/* Email List */}
          <div className="w-96 border-r border-border overflow-y-auto scrollbar-thin">
            {emails.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                <Mail className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No emails found</p>
                <p className="text-sm">Your emails will appear here once loaded.</p>
              </div>
            ) : (
              emails.map((email) => (
                <div
                  key={email.id}
                  className={cn(
                    "p-4 border-b border-border hover:bg-accent/50 cursor-pointer transition-colors",
                    selectedEmail?.id === email.id && "bg-accent/30"
                  )}
                  onClick={() => handleSelectEmail(email)}
                  data-testid={`email-item-${email.id}`}
                >
                  <div className="flex items-start space-x-3">
                    <Avatar className="w-10 h-10 flex-shrink-0">
                      <AvatarFallback className={getAvatarColor(email.senderEmail || email.sender || "")}>
                        <span className="text-white text-sm font-medium">
                          {getInitials(email.sender || "")}
                        </span>
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-medium text-foreground truncate" data-testid="text-email-sender">
                          {email.sender || "Unknown Sender"}
                        </p>
                        <span className="text-xs text-muted-foreground" data-testid="text-email-time">
                          {email.receivedAt 
                            ? formatDistanceToNow(new Date(email.receivedAt), { addSuffix: true })
                            : "Unknown"
                          }
                        </span>
                      </div>
                      
                      <p className="text-sm font-medium text-foreground truncate mt-1" data-testid="text-email-subject">
                        {email.subject || "No Subject"}
                      </p>
                      
                      <p className="text-sm text-muted-foreground truncate mt-1" data-testid="text-email-preview">
                        {email.body 
                          ? email.body.replace(/<[^>]*>/g, '').substring(0, 100) + "..."
                          : "No content preview"
                        }
                      </p>
                      
                      <div className="flex items-center space-x-2 mt-2">
                        {email.hasAttachments && (
                          <>
                            <Paperclip className="w-3 h-3 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground" data-testid="text-attachment-count">
                              {email.attachments?.length || 0} attachments
                            </span>
                          </>
                        )}
                        {!email.isRead && (
                          <Badge variant="secondary" className="text-xs">
                            Unread
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
          
          {/* Email Viewer */}
          <div className="flex-1">
            {selectedEmail ? (
              <div className="flex flex-col h-full">
                {/* Email Header */}
                <div className="p-6 border-b border-border">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-lg font-semibold" data-testid="text-email-subject">
                        {selectedEmail.subject || "No Subject"}
                      </h3>
                      <div className="flex items-center space-x-4 mt-2 text-sm text-muted-foreground">
                        <span data-testid="text-email-sender-full">
                          {selectedEmail.sender} {selectedEmail.senderEmail && `<${selectedEmail.senderEmail}>`}
                        </span>
                        <span data-testid="text-email-date">
                          {selectedEmail.receivedAt 
                            ? format(new Date(selectedEmail.receivedAt), "MMM d, yyyy 'at' h:mm a")
                            : "Unknown date"
                          }
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="icon" data-testid="button-reply-email">
                        <Reply className="h-4 w-4 text-muted-foreground" />
                      </Button>
                      <Button variant="ghost" size="icon" data-testid="button-forward-email">
                        <Forward className="h-4 w-4 text-muted-foreground" />
                      </Button>
                      <Button variant="ghost" size="icon" data-testid="button-archive-email">
                        <Archive className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Email Body */}
                <div className="flex-1 p-6 overflow-y-auto scrollbar-thin">
                  <div 
                    className="prose prose-gray max-w-none"
                    dangerouslySetInnerHTML={{ __html: selectedEmail.body || "No content available" }}
                    data-testid="email-content"
                  />
                </div>

                {/* Attachments Section */}
                {selectedEmail.hasAttachments && (
                  <div className="p-6 border-t border-border bg-muted/30">
                    <h4 className="font-medium mb-3 flex items-center space-x-2">
                      <Paperclip className="h-4 w-4 text-muted-foreground" />
                      <span>Attachments ({attachments.length})</span>
                    </h4>
                    
                    {attachmentsLoading ? (
                      <div className="text-center py-4 text-muted-foreground">
                        Loading attachments...
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {attachments.map((attachment: any) => (
                          <div 
                            key={attachment.id} 
                            className="flex items-center justify-between p-3 bg-card border border-border rounded-lg"
                            data-testid={`attachment-${attachment.id}`}
                          >
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                                <i className={getFileIcon(attachment.contentType || "")}></i>
                              </div>
                              <div>
                                <p className="font-medium text-sm" data-testid="text-attachment-name">
                                  {attachment.name || "Unknown file"}
                                </p>
                                <p className="text-xs text-muted-foreground" data-testid="text-attachment-size">
                                  {attachment.size ? formatFileSize(attachment.size) : "Unknown size"}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handlePreviewAttachment(attachment.id)}
                                data-testid={`button-preview-${attachment.id}`}
                              >
                                <Eye className="h-4 w-4 text-muted-foreground" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDownload(attachment.id)}
                                disabled={isDownloading}
                                data-testid={`button-download-${attachment.id}`}
                              >
                                <Download className="h-4 w-4 text-muted-foreground" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleSaveAttachment(attachment.id)}
                                data-testid={`button-save-${attachment.id}`}
                              >
                                <Save className="h-4 w-4 text-muted-foreground" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                <div className="text-center">
                  <Mail className="h-16 w-16 mx-auto mb-4 opacity-50" />
                  <h3 className="text-lg font-medium mb-2">Select an email</h3>
                  <p className="text-sm">Choose an email from the list to view its content.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
