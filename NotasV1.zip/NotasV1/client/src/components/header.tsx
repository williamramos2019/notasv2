import { useAuth } from "@/hooks/use-auth";
import { use# thoughts
I need to build a comprehensive notes and email management application with Microsoft OAuth 2.0 integration and Graph API. The application should allow users to authenticate with Microsoft, read emails from their inbox, view attachments, download them, and manage personal notes. This is a production-ready application, not a demo, so I need to implement real functionality.

Key components needed:
1. Microsoft OAuth 2.0 authentication flow using @azure/msal-browser and @azure/msal-node
2. Microsoft Graph API integration for email access
3. Notes CRUD operations with rich text editing
4. Secure attachment handling and downloads
5. Search functionality across notes and emails
6. Modern UI following the design reference

I'll need to set up the database schema for notes, implement proper OAuth flows, create the frontend components matching the design, and ensure proper error handling throughout.

# useful_guidelines_from_blueprints
When adding a database:
- Add the necessary Drizzle models and relations to `shared/schema.ts`
- Always explicitly model relations using the `relations` operator from `drizzle-orm`
- Update `server/storage.ts` to replace MemStorage with DatabaseStorage, making sure to adhere to the IStorage interface
- Execute the following shell command: `npm run db:push`

# directory_structure
```json
[
    {"path": "shared/schema.ts", "status": "overwritten"},
    {"path": "server/db.ts", "status": "new", "blueprint_source": "javascript_database"},
    {"path": "server/storage.ts", "status": "overwritten"},
    {"path": "server/routes.ts", "status": "overwritten"},
    {"path": "server/services/microsoft-auth.ts", "status": "new"},
    {"path": "server/services/graph-api.ts", "status": "new"},
    {"path": "client/src/pages/dashboard.tsx", "status": "new"},
    {"path": "client/src/pages/auth-callback.tsx", "status": "new"},
    {"path": "client/src/components/notes/notes-sidebar.tsx", "status": "new"},
    {"path": "client/src/components/notes/note-editor.tsx", "status": "new"},
    {"path": "client/src/components/notes/notes-list.tsx", "status": "new"},
    {"path": "client/src/components/email/email-modal.tsx", "status": "new"},
    {"path": "client/src/components/email/email-list.tsx", "status": "new"},
    {"path": "client/src/components/email/email-viewer.tsx", "status": "new"},
    {"path": "client/src/components/ui/rich-text-editor.tsx", "status": "new"},
    {"path": "client/src/components/layout/header.tsx", "status": "new"},
    {"path": "client/src/lib/microsoft-auth.ts", "status": "new"},
    {"path": "client/src/hooks/use-auth.ts", "status": "new"},
    {"path": "client/src/hooks/use-notes.ts", "status": "new"},
    {"path": "client/src/hooks/use-emails.ts", "status": "new"},
    {"path": "client/src/App.tsx", "status": "overwritten"},
    {"path": "client/src/index.css", "status": "overwritten"},
    {"path": "tailwind.config.ts", "status": "overwritten"}
]
