import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Search, Moon, Sun, ChevronDown } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

interface HeaderProps {
  onSearch: (query: string) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export function Header({ onSearch, darkMode, onToggleDarkMode }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const { user, logout, isLoggingOut } = useAuth();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  const getInitials = (name?: string) => {
    if (!name) return "U";
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };

  return (
    <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <i className="fas fa-sticky-note text-primary text-xl"></i>
          <h1 className="text-xl font-semibold text-foreground">NotasV1</h1>
        </div>
        <div className="hidden md:flex items-center space-x-1 text-sm text-muted-foreground">
          <span>Notes & Email Manager</span>
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        {/* Search Bar */}
        <div className="hidden md:flex items-center space-x-2">
          <form onSubmit={handleSearch} className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              type="text"
              placeholder="Search notes and emails..."
              className="pl-10 pr-4 py-2 w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search"
            />
          </form>
        </div>
        
        {/* Theme Toggle */}
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleDarkMode}
          data-testid="button-toggle-theme"
        >
          {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </Button>
        
        {/* User Profile */}
        <div className="flex items-center space-x-3">
          <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
            <i className="fab fa-microsoft mr-2"></i>
            Connected
          </Badge>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center space-x-2" data-testid="button-user-menu">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    {getInitials(user?.displayName)}
                  </AvatarFallback>
                </Avatar>
                <ChevronDown className="w-4 h-4 text-muted-foreground" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <div className="p-3 border-b border-border">
                <p className="font-medium text-popover-foreground" data-testid="text-user-name">
                  {user?.displayName || user?.username}
                </p>
                <p className="text-sm text-muted-foreground" data-testid="text-user-email">
                  {user?.email}
                </p>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => logout()}
                disabled={isLoggingOut}
                className="flex items-center space-x-2"
                data-testid="button-sign-out"
              >
                <i className="fab fa-microsoft text-sm"></i>
                <span>{isLoggingOut ? "Signing out..." : "Sign out from Microsoft"}</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
