import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { RichTextEditor } from "@/components/ui/rich-text-editor";
import { formatDistanceToNow } from "date-fns";
import { Share, Trash2, Save, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Note } from "@shared/schema";

interface NoteEditorProps {
  note?: Note;
  onSave: (noteData: { title: string; content: string; tags: string[] }) => void;
  onDelete?: () => void;
  isLoading?: boolean;
  className?: string;
}

export function NoteEditor({ note, onSave, onDelete, isLoading, className }: NoteEditorProps) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);

  useEffect(() => {
    if (note) {
      setTitle(note.title);
      setContent(note.content);
      setTags(note.tags || []);
      setHasUnsavedChanges(false);
      setLastSaved(new Date(note.updatedAt));
    } else {
      setTitle("");
      setContent("");
      setTags([]);
      setHasUnsavedChanges(false);
      setLastSaved(null);
    }
  }, [note]);

  useEffect(() => {
    if (note) {
      setHasUnsavedChanges(
        title !== note.title || 
        content !== note.content || 
        JSON.stringify(tags) !== JSON.stringify(note.tags || [])
      );
    } else {
      setHasUnsavedChanges(title.length > 0 || content.length > 0);
    }
  }, [title, content, tags, note]);

  const handleSave = () => {
    onSave({ title, content, tags });
    setHasUnsavedChanges(false);
    setLastSaved(new Date());
  };

  // Auto-save functionality
  useEffect(() => {
    if (hasUnsavedChanges && (title.length > 0 || content.length > 0)) {
      const timer = setTimeout(() => {
        handleSave();
      }, 2000); // Auto-save after 2 seconds of inactivity

      return () => clearTimeout(timer);
    }
  }, [title, content, tags, hasUnsavedChanges]);

  const getWordCount = (text: string) => {
    const cleanText = text.replace(/<[^>]*>/g, '').trim();
    return cleanText.length > 0 ? cleanText.split(/\s+/).length : 0;
  };

  if (!note && title.length === 0 && content.length === 0) {
    return (
      <div className={cn("flex-1 flex flex-col items-center justify-center bg-background", className)}>
        <div className="text-center text-muted-foreground max-w-md">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-sticky-note text-2xl opacity-50"></i>
          </div>
          <h3 className="text-lg font-medium mb-2">Select a note to edit</h3>
          <p className="text-sm">Choose a note from the sidebar or create a new one to get started.</p>
        </div>
      </div>
    );
  }

  return (
    <div className={cn("flex-1 flex flex-col bg-background", className)}>
      {/* Header */}
      <div className="p-6 border-b border-border bg-card">
        <div className="flex items-center justify-between">
          <div className="flex-1 min-w-0">
            <Input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Note title..."
              className="text-2xl font-bold bg-transparent border-none outline-none p-0 h-auto text-foreground placeholder:text-muted-foreground"
              data-testid="input-note-title"
            />
            <div className="flex items-center space-x-4 mt-2 text-sm text-muted-foreground">
              {note && (
                <>
                  <span data-testid="text-note-created">
                    Created {formatDistanceToNow(new Date(note.createdAt), { addSuffix: true })}
                  </span>
                  <span data-testid="text-note-modified">
                    Modified {formatDistanceToNow(new Date(note.updatedAt), { addSuffix: true })}
                  </span>
                </>
              )}
              <span data-testid="text-word-count">
                {getWordCount(content)} words
              </span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" data-testid="button-share-note">
              <Share className="h-4 w-4 text-muted-foreground" />
            </Button>
            {onDelete && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={onDelete}
                data-testid="button-delete-note"
              >
                <Trash2 className="h-4 w-4 text-muted-foreground" />
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Rich Text Editor */}
      <div className="flex-1 p-6 overflow-y-auto">
        <RichTextEditor
          content={content}
          onChange={setContent}
          placeholder="Start writing your note..."
          className="h-full"
        />
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-border bg-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            {/* Tag indicators */}
            <div className="flex items-center space-x-2">
              {tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              {hasUnsavedChanges ? (
                <>
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <span>Unsaved changes</span>
                </>
              ) : (
                <>
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Saved</span>
                </>
              )}
            </div>
            
            {lastSaved && (
              <span className="text-sm text-muted-foreground">
                Auto-save: {formatDistanceToNow(lastSaved, { addSuffix: true })}
              </span>
            )}
            
            <Button
              onClick={handleSave}
              disabled={!hasUnsavedChanges || isLoading}
              size="sm"
              data-testid="button-save-note"
            >
              <Save className="mr-2 h-4 w-4" />
              Save
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
