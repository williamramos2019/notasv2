import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StickyNote, Mail, Inbox, Send, Archive, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

interface NotesSidebarProps {
  activeView: "notes" | "emails";
  onViewChange: (view: "notes" | "emails") => void;
  onCreateNote: () => void;
  notesCount: number;
  emailsCount: number;
  className?: string;
}

export function NotesSidebar({ 
  activeView, 
  onViewChange, 
  onCreateNote, 
  notesCount, 
  emailsCount,
  className 
}: NotesSidebarProps) {
  return (
    <aside className={cn("w-64 bg-card border-r border-border flex flex-col", className)}>
      <nav className="flex-1 p-4 space-y-2">
        <div className="space-y-1">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-2 py-1">
            Navigation
          </h3>
          <Button
            variant={activeView === "notes" ? "secondary" : "ghost"}
            className="w-full justify-start"
            onClick={() => onViewChange("notes")}
            data-testid="button-navigate-notes"
          >
            <StickyNote className="mr-3 h-4 w-4" />
            <span className="font-medium">Notes</span>
            <Badge variant="outline" className="ml-auto" data-testid="badge-notes-count">
              {notesCount}
            </Badge>
          </Button>
          <Button
            variant={activeView === "emails" ? "secondary" : "ghost"}
            className="w-full justify-start"
            onClick={() => onViewChange("emails")}
            data-testid="button-navigate-emails"
          >
            <Mail className="mr-3 h-4 w-4" />
            <span className="font-medium">Emails</span>
            <Badge variant="outline" className="ml-auto" data-testid="badge-emails-count">
              {emailsCount}
            </Badge>
          </Button>
        </div>
        
        <div className="space-y-1 pt-4">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-2 py-1">
            Email Folders
          </h3>
          <Button variant="ghost" className="w-full justify-start" data-testid="button-inbox">
            <Inbox className="mr-3 h-4 w-4" />
            <span className="font-medium">Inbox</span>
            <span className="ml-auto text-xs text-muted-foreground">5</span>
          </Button>
          <Button variant="ghost" className="w-full justify-start" data-testid="button-sent">
            <Send className="mr-3 h-4 w-4" />
            <span className="font-medium">Sent</span>
            <span className="ml-auto text-xs text-muted-foreground">3</span>
          </Button>
          <Button variant="ghost" className="w-full justify-start" data-testid="button-archive">
            <Archive className="mr-3 h-4 w-4" />
            <span className="font-medium">Archive</span>
          </Button>
        </div>
        
        <div className="space-y-1 pt-4">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-2 py-1">
            Tags
          </h3>
          <div className="space-y-1">
            <Button variant="ghost" className="w-full justify-start" data-testid="button-tag-work">
              <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
              <span className="font-medium">Work</span>
              <span className="ml-auto text-xs text-muted-foreground">4</span>
            </Button>
            <Button variant="ghost" className="w-full justify-start" data-testid="button-tag-personal">
              <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
              <span className="font-medium">Personal</span>
              <span className="ml-auto text-xs text-muted-foreground">6</span>
            </Button>
            <Button variant="ghost" className="w-full justify-start" data-testid="button-tag-important">
              <div className="w-3 h-3 bg-red-500 rounded-full mr-3"></div>
              <span className="font-medium">Important</span>
              <span className="ml-auto text-xs text-muted-foreground">2</span>
            </Button>
          </div>
        </div>
      </nav>
      
      {/* Create New Note Button */}
      <div className="p-4 border-t border-border">
        <Button 
          className="w-full" 
          onClick={onCreateNote}
          data-testid="button-create-note"
        >
          <Plus className="mr-2 h-4 w-4" />
          New Note
        </Button>
      </div>
    </aside>
  );
}
