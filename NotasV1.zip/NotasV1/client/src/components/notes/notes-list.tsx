import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";
import { Star, Paperclip, MoreVertical, ArrowDownWideNarrow, RefreshCw } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Note } from "@shared/schema";

interface NotesListProps {
  notes: Note[];
  selectedNoteId?: string;
  onSelectNote: (note: Note) => void;
  onToggleFavorite: (noteId: string) => void;
  onRefresh: () => void;
  isLoading?: boolean;
  className?: string;
}

export function NotesList({ 
  notes, 
  selectedNoteId, 
  onSelectNote, 
  onToggleFavorite, 
  onRefresh,
  isLoading,
  className 
}: NotesListProps) {
  const getTagColor = (tag: string) => {
    const colors: Record<string, string> = {
      work: "bg-blue-500",
      personal: "bg-green-500",
      important: "bg-red-500",
    };
    return colors[tag.toLowerCase()] || "bg-gray-500";
  };

  return (
    <div className={cn("w-80 bg-card border-r border-border flex flex-col", className)}>
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Notes</h2>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" data-testid="button-sort-notes">
              <ArrowDownWideNarrow className="h-4 w-4 text-muted-foreground" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onRefresh}
              disabled={isLoading}
              data-testid="button-refresh-notes"
            >
              <RefreshCw className={cn("h-4 w-4 text-muted-foreground", isLoading && "animate-spin")} />
            </Button>
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        {notes.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">
            <StickyNote className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No notes yet</p>
            <p className="text-sm">Create your first note to get started</p>
          </div>
        ) : (
          notes.map((note) => (
            <div
              key={note.id}
              className={cn(
                "p-4 border-b border-border hover:bg-accent/50 cursor-pointer transition-colors",
                selectedNoteId === note.id && "bg-accent/30"
              )}
              onClick={() => onSelectNote(note)}
              data-testid={`note-item-${note.id}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-foreground truncate" data-testid="text-note-title">
                    {note.title || "Untitled"}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2" data-testid="text-note-preview">
                    {note.content.length > 0 
                      ? note.content.replace(/<[^>]*>/g, '').substring(0, 100) + "..."
                      : "No content"
                    }
                  </p>
                  <div className="flex items-center space-x-2 mt-2">
                    {note.tags && note.tags.length > 0 && (
                      <div className={cn("w-2 h-2 rounded-full", getTagColor(note.tags[0]))}></div>
                    )}
                    <span className="text-xs text-muted-foreground" data-testid="text-note-date">
                      {formatDistanceToNow(new Date(note.updatedAt), { addSuffix: true })}
                    </span>
                    {/* Show paperclip if note has attachments - placeholder for now */}
                    {/* <Paperclip className="w-3 h-3 text-muted-foreground" /> */}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="ml-2 h-8 w-8"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleFavorite(note.id);
                  }}
                  data-testid={`button-toggle-favorite-${note.id}`}
                >
                  <Star 
                    className={cn(
                      "h-4 w-4",
                      note.isFavorite 
                        ? "text-yellow-500 fill-yellow-500" 
                        : "text-muted-foreground"
                    )} 
                  />
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
