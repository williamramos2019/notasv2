import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { formatDistanceToNow, format } from "date-fns";
import { Reply, Forward, Archive, Download, Eye, Save } from "lucide-react";
import { useEmailAttachments, useDownloadAttachment } from "@/hooks/use-emails";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import type { EmailCache } from "@shared/schema";

interface EmailViewerProps {
  email: EmailCache;
  className?: string;
}

export function EmailViewer({ email, className }: EmailViewerProps) {
  const { attachments, isLoading: attachmentsLoading } = useEmailAttachments(email.id);
  const { downloadAttachment, isDownloading } = useDownloadAttachment();
  const { toast } = useToast();

  const getInitials = (name: string) => {
    if (!name) return "?";
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType.includes("pdf")) return "fas fa-file-pdf text-red-600";
    if (mimeType.includes("excel") || mimeType.includes("sheet")) return "fas fa-file-excel text-green-600";
    if (mimeType.includes("word") || mimeType.includes("document")) return "fas fa-file-word text-blue-600";
    if (mimeType.includes("image")) return "fas fa-file-image text-purple-600";
    return "fas fa-file text-gray-600";
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const handleDownload = (attachmentId: string) => {
    downloadAttachment({ emailId: email.id, attachmentId });
  };

  const handleSaveAttachment = (attachmentId: string) => {
    // TODO: Implement save to notes system
    toast({ 
      title: "Feature Coming Soon", 
      description: "Save to notes system will be available soon!" 
    });
  };

  const handlePreviewAttachment = (attachmentId: string) => {
    // TODO: Implement preview functionality
    toast({ 
      title: "Feature Coming Soon", 
      description: "Attachment preview will be available soon!" 
    });
  };

  return (
    <div className={cn("flex flex-col h-full", className)}>
      {/* Email Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-lg font-semibold" data-testid="text-email-subject">
              {email.subject || "No Subject"}
            </h3>
            <div className="flex items-center space-x-4 mt-2 text-sm text-muted-foreground">
              <span data-testid="text-email-sender-full">
                {email.sender} {email.senderEmail && `<${email.senderEmail}>`}
              </span>
              <span data-testid="text-email-date">
                {email.receivedAt 
                  ? format(new Date(email.receivedAt), "MMM d, yyyy 'at' h:mm a")
                  : "Unknown date"
                }
              </span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" data-testid="button-reply-email">
              <Reply className="h-4 w-4 text-muted-foreground" />
            </Button>
            <Button variant="ghost" size="icon" data-testid="button-forward-email">
              <Forward className="h-4 w-4 text-muted-foreground" />
            </Button>
            <Button variant="ghost" size="icon" data-testid="button-archive-email">
              <Archive className="h-4 w-4 text-muted-foreground" />
            </Button>
          </div>
        </div>
      </div>

      {/* Email Body */}
      <div className="flex-1 p-6 overflow-y-auto scrollbar-thin">
        <div 
          className="prose prose-gray max-w-none"
          dangerouslySetInnerHTML={{ __html: email.body || "No content available" }}
          data-testid="email-content"
        />
      </div>

      {/* Attachments Section */}
      {email.hasAttachments && (
        <div className="p-6 border-t border-border bg-muted/30">
          <h4 className="font-medium mb-3 flex items-center space-x-2">
            <i className="fas fa-paperclip text-muted-foreground"></i>
            <span>Attachments ({attachments.length})</span>
          </h4>
          
          {attachmentsLoading ? (
            <div className="text-center py-4 text-muted-foreground">
              Loading attachments...
            </div>
          ) : (
            <div className="space-y-2">
              {attachments.map((attachment: any) => (
                <div 
                  key={attachment.id} 
                  className="flex items-center justify-between p-3 bg-card border border-border rounded-lg"
                  data-testid={`attachment-${attachment.id}`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                      <i className={getFileIcon(attachment.contentType || "")}></i>
                    </div>
                    <div>
                      <p className="font-medium text-sm" data-testid="text-attachment-name">
                        {attachment.name || "Unknown file"}
                      </p>
                      <p className="text-xs text-muted-foreground" data-testid="text-attachment-size">
                        {attachment.size ? formatFileSize(attachment.size) : "Unknown size"}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handlePreviewAttachment(attachment.id)}
                      data-testid={`button-preview-${attachment.id}`}
                    >
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDownload(attachment.id)}
                      disabled={isDownloading}
                      data-testid={`button-download-${attachment.id}`}
                    >
                      <Download className="h-4 w-4 text-muted-foreground" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleSaveAttachment(attachment.id)}
                      data-testid={`button-save-${attachment.id}`}
                    >
                      <Save className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
