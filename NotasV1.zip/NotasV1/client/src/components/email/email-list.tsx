import { formatDistanceToNow } from "date-fns";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Paperclip } from "lucide-react";
import { cn } from "@/lib/utils";
import type { EmailCache } from "@shared/schema";

interface EmailListProps {
  emails: EmailCache[];
  selectedEmailId?: string;
  onSelectEmail: (email: EmailCache) => void;
  className?: string;
}

export function EmailList({ emails, selectedEmailId, onSelectEmail, className }: EmailListProps) {
  const getInitials = (name: string) => {
    if (!name) return "?";
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };

  const getAvatarColor = (email: string) => {
    // Simple hash function to get consistent colors
    let hash = 0;
    for (let i = 0; i < email.length; i++) {
      hash = email.charCodeAt(i) + ((hash << 5) - hash);
    }
    const colors = [
      "bg-red-500", "bg-blue-500", "bg-green-500", "bg-yellow-500", 
      "bg-purple-500", "bg-pink-500", "bg-indigo-500", "bg-orange-500"
    ];
    return colors[Math.abs(hash) % colors.length];
  };

  if (emails.length === 0) {
    return (
      <div className={cn("border-r border-border overflow-y-auto p-8 text-center text-muted-foreground", className)}>
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="fas fa-envelope text-2xl opacity-50"></i>
        </div>
        <p>No emails found</p>
        <p className="text-sm">Your emails will appear here once loaded.</p>
      </div>
    );
  }

  return (
    <div className={cn("border-r border-border overflow-y-auto scrollbar-thin", className)}>
      {emails.map((email) => (
        <div
          key={email.id}
          className={cn(
            "p-4 border-b border-border hover:bg-accent/50 cursor-pointer transition-colors",
            selectedEmailId === email.id && "bg-accent/30"
          )}
          onClick={() => onSelectEmail(email)}
          data-testid={`email-item-${email.id}`}
        >
          <div className="flex items-start space-x-3">
            <Avatar className="w-10 h-10 flex-shrink-0">
              <AvatarFallback className={getAvatarColor(email.senderEmail || email.sender || "")}>
                <span className="text-white text-sm font-medium">
                  {getInitials(email.sender || "")}
                </span>
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <p className="font-medium text-foreground truncate" data-testid="text-email-sender">
                  {email.sender || "Unknown Sender"}
                </p>
                <span className="text-xs text-muted-foreground" data-testid="text-email-time">
                  {email.receivedAt 
                    ? formatDistanceToNow(new Date(email.receivedAt), { addSuffix: true })
                    : "Unknown"
                  }
                </span>
              </div>
              
              <p className="text-sm font-medium text-foreground truncate mt-1" data-testid="text-email-subject">
                {email.subject || "No Subject"}
              </p>
              
              <p className="text-sm text-muted-foreground truncate mt-1" data-testid="text-email-preview">
                {email.body 
                  ? email.body.replace(/<[^>]*>/g, '').substring(0, 100) + "..."
                  : "No content preview"
                }
              </p>
              
              <div className="flex items-center space-x-2 mt-2">
                {email.hasAttachments && (
                  <>
                    <Paperclip className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground" data-testid="text-attachment-count">
                      {email.attachments?.length || 0} attachments
                    </span>
                  </>
                )}
                {!email.isRead && (
                  <Badge variant="secondary" className="text-xs">
                    Unread
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
