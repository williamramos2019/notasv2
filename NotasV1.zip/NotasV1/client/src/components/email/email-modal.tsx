import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { EmailList } from "./email-list";
import { EmailViewer } from "./email-viewer";
import { X, RefreshCw } from "lucide-react";
import { useEmails } from "@/hooks/use-emails";
import type { EmailCache } from "@shared/schema";

interface EmailModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function EmailModal({ isOpen, onClose }: EmailModalProps) {
  const [selectedEmail, setSelectedEmail] = useState<EmailCache | null>(null);
  const { emails, refreshEmails, isRefreshing } = useEmails("inbox");

  const handleSelectEmail = (email: EmailCache) => {
    setSelectedEmail(email);
  };

  const handleCloseModal = () => {
    setSelectedEmail(null);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleCloseModal}>
      <DialogContent className="max-w-7xl max-h-[90vh] p-0">
        <DialogHeader className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-semibold">
              Microsoft Outlook - Inbox
            </DialogTitle>
            <div className="flex items-center space-x-2">
              <Badge variant="secondary" className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 border-green-200 dark:border-green-800">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                Connected to Microsoft Graph
              </Badge>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => refreshEmails()}
                disabled={isRefreshing}
                data-testid="button-refresh-emails"
              >
                <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleCloseModal}
                data-testid="button-close-email-modal"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>
        
        <div className="flex flex-1 overflow-hidden">
          <EmailList
            emails={emails}
            selectedEmailId={selectedEmail?.id}
            onSelectEmail={handleSelectEmail}
            className="w-96"
          />
          
          <div className="flex-1">
            {selectedEmail ? (
              <EmailViewer email={selectedEmail} />
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                <div className="text-center">
                  <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-envelope text-2xl opacity-50"></i>
                  </div>
                  <h3 className="text-lg font-medium mb-2">Select an email</h3>
                  <p className="text-sm">Choose an email from the list to view its content.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
