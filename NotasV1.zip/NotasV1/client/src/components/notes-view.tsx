import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";
import { 
  Star, 
  Paperclip, 
  ArrowDownWideNarrow, 
  RefreshCw, 
  Share, 
  Trash2, 
  Save,
  Bold,
  Italic,
  Underline,
  Link,
  Image,
  Code
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useNotes } from "@/hooks/use-notes";
import type { Note } from "@shared/schema";

interface NotesViewProps {
  selectedNoteId: string | null;
  onNoteSelect: (noteId: string) => void;
  searchQuery: string;
  selectedTag: string | null;
  "data-testid"?: string;
}

export default function NotesView({ 
  selectedNoteId, 
  onNoteSelect, 
  searchQuery, 
  selectedTag,
  ...props 
}: NotesViewProps) {
  const { notes, createNote, updateNote, deleteNote, isLoading } = useNotes();
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Filter notes based on search and tag
  const filteredNotes = notes.filter(note => {
    const matchesSearch = !searchQuery || 
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.content.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesTag = !selectedTag || (note.tags && note.tags.includes(selectedTag));
    
    return matchesSearch && matchesTag;
  });

  // Handle note selection
  useEffect(() => {
    if (selectedNoteId) {
      const note = notes.find(n => n.id === selectedNoteId);
      if (note) {
        setSelectedNote(note);
        setTitle(note.title);
        setContent(note.content);
        setHasUnsavedChanges(false);
      }
    } else {
      setSelectedNote(null);
      setTitle("");
      setContent("");
      setHasUnsavedChanges(false);
    }
  }, [selectedNoteId, notes]);

  // Track changes
  useEffect(() => {
    if (selectedNote) {
      setHasUnsavedChanges(
        title !== selectedNote.title || content !== selectedNote.content
      );
    } else {
      setHasUnsavedChanges(title.length > 0 || content.length > 0);
    }
  }, [title, content, selectedNote]);

  const handleSave = () => {
    if (selectedNote) {
      updateNote({ id: selectedNote.id, title, content });
    } else if (title || content) {
      createNote({ title: title || "Untitled", content, tags: [] });
    }
    setHasUnsavedChanges(false);
  };

  const handleDelete = () => {
    if (selectedNote) {
      deleteNote(selectedNote.id);
      setSelectedNote(null);
      setTitle("");
      setContent("");
    }
  };

  const handleToggleFavorite = (noteId: string) => {
    const note = notes.find(n => n.id === noteId);
    if (note) {
      updateNote({ id: noteId, isFavorite: !note.isFavorite });
    }
  };

  const getTagColor = (tag: string) => {
    const colors: Record<string, string> = {
      work: "bg-blue-500",
      personal: "bg-green-500",
      important: "bg-red-500",
    };
    return colors[tag.toLowerCase()] || "bg-gray-500";
  };

  const getWordCount = (text: string) => {
    const cleanText = text.replace(/<[^>]*>/g, '').trim();
    return cleanText.length > 0 ? cleanText.split(/\s+/).length : 0;
  };

  return (
    <div className="flex-1 flex overflow-hidden" {...props}>
      {/* Notes List */}
      <div className="w-80 bg-card border-r border-border flex flex-col">
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Notes</h2>
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="icon" data-testid="button-sort-notes">
                <ArrowDownWideNarrow className="h-4 w-4 text-muted-foreground" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                disabled={isLoading}
                data-testid="button-refresh-notes"
              >
                <RefreshCw className={cn("h-4 w-4 text-muted-foreground", isLoading && "animate-spin")} />
              </Button>
            </div>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto scrollbar-thin">
          {filteredNotes.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              <StickyNote className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No notes found</p>
              <p className="text-sm">
                {searchQuery || selectedTag ? "Try adjusting your filters" : "Create your first note to get started"}
              </p>
            </div>
          ) : (
            filteredNotes.map((note) => (
              <div
                key={note.id}
                className={cn(
                  "p-4 border-b border-border hover:bg-accent/50 cursor-pointer transition-colors",
                  selectedNoteId === note.id && "bg-accent/30"
                )}
                onClick={() => onNoteSelect(note.id)}
                data-testid={`note-item-${note.id}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-foreground truncate" data-testid="text-note-title">
                      {note.title || "Untitled"}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2" data-testid="text-note-preview">
                      {note.content.length > 0 
                        ? note.content.replace(/<[^>]*>/g, '').substring(0, 100) + "..."
                        : "No content"
                      }
                    </p>
                    <div className="flex items-center space-x-2 mt-2">
                      {note.tags && note.tags.length > 0 && (
                        <div className={cn("w-2 h-2 rounded-full", getTagColor(note.tags[0]))}></div>
                      )}
                      <span className="text-xs text-muted-foreground" data-testid="text-note-date">
                        {formatDistanceToNow(new Date(note.updatedAt), { addSuffix: true })}
                      </span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="ml-2 h-8 w-8"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleFavorite(note.id);
                    }}
                    data-testid={`button-toggle-favorite-${note.id}`}
                  >
                    <Star 
                      className={cn(
                        "h-4 w-4",
                        note.isFavorite 
                          ? "text-yellow-500 fill-yellow-500" 
                          : "text-muted-foreground"
                      )} 
                    />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
      
      {/* Note Editor */}
      <div className="flex-1 flex flex-col bg-background">
        {!selectedNote && !title && !content ? (
          <div className="flex-1 flex flex-col items-center justify-center">
            <div className="text-center text-muted-foreground max-w-md">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <StickyNote className="h-8 w-8 opacity-50" />
              </div>
              <h3 className="text-lg font-medium mb-2">Select a note to edit</h3>
              <p className="text-sm">Choose a note from the sidebar or create a new one to get started.</p>
            </div>
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="p-6 border-b border-border bg-card">
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <Input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Note title..."
                    className="text-2xl font-bold bg-transparent border-none outline-none p-0 h-auto text-foreground placeholder:text-muted-foreground"
                    data-testid="input-note-title"
                  />
                  <div className="flex items-center space-x-4 mt-2 text-sm text-muted-foreground">
                    {selectedNote && (
                      <>
                        <span data-testid="text-note-created">
                          Created {formatDistanceToNow(new Date(selectedNote.createdAt), { addSuffix: true })}
                        </span>
                        <span data-testid="text-note-modified">
                          Modified {formatDistanceToNow(new Date(selectedNote.updatedAt), { addSuffix: true })}
                        </span>
                      </>
                    )}
                    <span data-testid="text-word-count">
                      {getWordCount(content)} words
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="icon" data-testid="button-share-note">
                    <Share className="h-4 w-4 text-muted-foreground" />
                  </Button>
                  {selectedNote && (
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={handleDelete}
                      data-testid="button-delete-note"
                    >
                      <Trash2 className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  )}
                </div>
              </div>
            </div>

            {/* Rich Text Editor */}
            <div className="flex-1 p-6 overflow-y-auto">
              <div className="bg-card rounded-lg border border-border">
                {/* Toolbar */}
                <div className="flex items-center space-x-1 p-2 border-b border-border bg-muted/30">
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0" data-testid="button-format-bold">
                    <Bold className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0" data-testid="button-format-italic">
                    <Italic className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0" data-testid="button-format-underline">
                    <Underline className="h-4 w-4" />
                  </Button>
                  <div className="w-px h-6 bg-border mx-2"></div>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0" data-testid="button-format-link">
                    <Link className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0" data-testid="button-format-image">
                    <Image className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0" data-testid="button-format-code">
                    <Code className="h-4 w-4" />
                  </Button>
                </div>

                {/* Editor */}
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Start writing your note..."
                  className="w-full h-96 p-4 resize-none border-none outline-none bg-transparent text-foreground placeholder:text-muted-foreground"
                  data-testid="textarea-note-content"
                />
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-border bg-card">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  {selectedNote?.tags && selectedNote.tags.length > 0 && (
                    <div className="flex items-center space-x-2">
                      {selectedNote.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    {hasUnsavedChanges ? (
                      <>
                        <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                        <span>Unsaved changes</span>
                      </>
                    ) : (
                      <>
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span>Saved</span>
                      </>
                    )}
                  </div>
                  
                  <Button
                    onClick={handleSave}
                    disabled={!hasUnsavedChanges}
                    size="sm"
                    data-testid="button-save-note"
                  >
                    <Save className="mr-2 h-4 w-4" />
                    Save
                  </Button>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
