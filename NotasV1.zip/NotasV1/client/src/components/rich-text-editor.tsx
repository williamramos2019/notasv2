import { useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  Bold, 
  Italic, 
  Underline, 
  Link, 
  Image, 
  Code,
  List,
  ListOrdered,
  Quote,
  Heading1,
  Heading2,
  Heading3
} from "lucide-react";
import { cn } from "@/lib/utils";

interface RichTextEditorProps {
  content: string;
  onChange: (content: string) => void;
  placeholder?: string;
  className?: string;
}

export default function RichTextEditor({ content, onChange, placeholder, className }: RichTextEditorProps) {
  const [editorRef, setEditorRef] = useState<HTMLDivElement | null>(null);

  const executeCommand = useCallback((command: string, value?: string) => {
    document.execCommand(command, false, value);
    if (editorRef) {
      onChange(editorRef.innerHTML);
    }
  }, [editorRef, onChange]);

  const handleInput = useCallback(() => {
    if (editorRef) {
      onChange(editorRef.innerHTML);
    }
  }, [editorRef, onChange]);

  useEffect(() => {
    if (editorRef && editorRef.innerHTML !== content) {
      editorRef.innerHTML = content;
    }
  }, [content, editorRef]);

  const toolbarButtons = [
    { icon: Bold, command: "bold", title: "Bold" },
    { icon: Italic, command: "italic", title: "Italic" },
    { icon: Underline, command: "underline", title: "Underline" },
    null, // Separator
    { icon: Heading1, command: "formatBlock", value: "h1", title: "Heading 1" },
    { icon: Heading2, command: "formatBlock", value: "h2", title: "Heading 2" },
    { icon: Heading3, command: "formatBlock", value: "h3", title: "Heading 3" },
    null, // Separator
    { icon: List, command: "insertUnorderedList", title: "Bullet List" },
    { icon: ListOrdered, command: "insertOrderedList", title: "Numbered List" },
    { icon: Quote, command: "formatBlock", value: "blockquote", title: "Quote" },
    null, // Separator
    { icon: Link, command: "createLink", title: "Insert Link", requiresValue: true },
    { icon: Image, command: "insertImage", title: "Insert Image", requiresValue: true },
    { icon: Code, command: "formatBlock", value: "pre", title: "Code Block" },
  ];

  const handleButtonClick = (button: any) => {
    if (button.requiresValue) {
      const value = prompt(`Enter ${button.title.toLowerCase()}:`);
      if (value) {
        executeCommand(button.command, value);
      }
    } else {
      executeCommand(button.command, button.value);
    }
  };

  return (
    <div className={cn("border border-border rounded-lg", className)}>
      {/* Toolbar */}
      <div className="flex items-center space-x-1 p-2 border-b border-border bg-muted/30">
        {toolbarButtons.map((button, index) => {
          if (button === null) {
            return <Separator key={index} orientation="vertical" className="h-6" />;
          }

          const Icon = button.icon;
          return (
            <Button
              key={button.command + (button.value || "")}
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0"
              onClick={() => handleButtonClick(button)}
              title={button.title}
              data-testid={`button-format-${button.command}`}
            >
              <Icon className="h-4 w-4" />
            </Button>
          );
        })}
      </div>

      {/* Editor */}
      <div
        ref={setEditorRef}
        contentEditable
        className="p-4 min-h-[300px] max-h-[600px] overflow-y-auto focus:outline-none prose prose-gray max-w-none"
        onInput={handleInput}
        style={{ wordWrap: "break-word" }}
        suppressContentEditableWarning={true}
        data-placeholder={placeholder}
        data-testid="rich-text-editor"
      />
    </div>
  );
}
