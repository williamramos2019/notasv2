import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Note, InsertNote } from "@shared/schema";

export function useNotes() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: notes = [], isLoading, error } = useQuery<Note[]>({
    queryKey: ["/api/notes"],
  });

  const createNoteMutation = useMutation({
    mutationFn: async (noteData: Omit<InsertNote, "userId">) => {
      const response = await apiRequest("POST", "/api/notes", noteData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      toast({ title: "Success", description: "Note created successfully!" });
    },
    onError: (error) => {
      console.error("Create note error:", error);
      toast({ title: "Error", description: "Failed to create note", variant: "destructive" });
    },
  });

  const updateNoteMutation = useMutation({
    mutationFn: async ({ id, ...data }: Partial<InsertNote> & { id: string }) => {
      const response = await apiRequest("PUT", `/api/notes/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
    },
    onError: (error) => {
      console.error("Update note error:", error);
      toast({ title: "Error", description: "Failed to update note", variant: "destructive" });
    },
  });

  const deleteNoteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/notes/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      toast({ title: "Success", description: "Note deleted successfully!" });
    },
    onError: (error) => {
      console.error("Delete note error:", error);
      toast({ title: "Error", description: "Failed to delete note", variant: "destructive" });
    },
  });

  return {
    notes,
    isLoading,
    error,
    createNote: createNoteMutation.mutate,
    updateNote: updateNoteMutation.mutate,
    deleteNote: deleteNoteMutation.mutate,
    isCreating: createNoteMutation.isPending,
    isUpdating: updateNoteMutation.isPending,
    isDeleting: deleteNoteMutation.isPending,
  };
}

export function useNote(id: string) {
  const queryClient = useQueryClient();

  const { data: note, isLoading, error } = useQuery<Note>({
    queryKey: ["/api/notes", id],
    enabled: !!id,
  });

  return {
    note,
    isLoading,
    error,
  };
}

export function useSearchNotes() {
  const { toast } = useToast();

  const searchMutation = useMutation({
    mutationFn: async (query: string) => {
      const response = await apiRequest("GET", `/api/search?q=${encodeURIComponent(query)}&type=notes`);
      return response.json();
    },
    onError: (error) => {
      console.error("Search error:", error);
      toast({ title: "Error", description: "Search failed", variant: "destructive" });
    },
  });

  return {
    search: searchMutation.mutate,
    searchResults: searchMutation.data?.notes || [],
    isSearching: searchMutation.isPending,
  };
}
