import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { EmailCache } from "@shared/schema";

export function useEmails(folder: string = "inbox") {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: emails = [], isLoading, error } = useQuery<EmailCache[]>({
    queryKey: ["/api/emails", folder],
  });

  const refreshEmailsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("GET", `/api/emails?folder=${folder}&refresh=true`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emails", folder] });
      toast({ title: "Success", description: "Emails refreshed!" });
    },
    onError: (error) => {
      console.error("Refresh emails error:", error);
      toast({ title: "Error", description: "Failed to refresh emails", variant: "destructive" });
    },
  });

  return {
    emails,
    isLoading,
    error,
    refreshEmails: refreshEmailsMutation.mutate,
    isRefreshing: refreshEmailsMutation.isPending,
  };
}

export function useEmail(id: string) {
  const { data: email, isLoading, error } = useQuery<EmailCache>({
    queryKey: ["/api/emails", id],
    enabled: !!id,
  });

  return {
    email,
    isLoading,
    error,
  };
}

export function useEmailAttachments(emailId: string) {
  const { data: attachments = [], isLoading, error } = useQuery({
    queryKey: ["/api/emails", emailId, "attachments"],
    enabled: !!emailId,
  });

  return {
    attachments,
    isLoading,
    error,
  };
}

export function useDownloadAttachment() {
  const { toast } = useToast();

  const downloadMutation = useMutation({
    mutationFn: async ({ emailId, attachmentId }: { emailId: string; attachmentId: string }) => {
      const response = await fetch(`/api/emails/${emailId}/attachments/${attachmentId}/download`);
      if (!response.ok) {
        throw new Error("Download failed");
      }
      
      const blob = await response.blob();
      const contentDisposition = response.headers.get("content-disposition");
      const fileName = contentDisposition 
        ? contentDisposition.split("filename=")[1]?.replace(/"/g, "") 
        : "attachment";
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Attachment downloaded!" });
    },
    onError: (error) => {
      console.error("Download error:", error);
      toast({ title: "Error", description: "Failed to download attachment", variant: "destructive" });
    },
  });

  return {
    downloadAttachment: downloadMutation.mutate,
    isDownloading: downloadMutation.isPending,
  };
}

export function useSearchEmails() {
  const { toast } = useToast();

  const searchMutation = useMutation({
    mutationFn: async (query: string) => {
      const response = await apiRequest("GET", `/api/search?q=${encodeURIComponent(query)}&type=emails`);
      return response.json();
    },
    onError: (error) => {
      console.error("Search error:", error);
      toast({ title: "Error", description: "Search failed", variant: "destructive" });
    },
  });

  return {
    search: searchMutation.mutate,
    searchResults: searchMutation.data?.emails || [],
    isSearching: searchMutation.isPending,
  };
}
