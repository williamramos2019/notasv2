import { apiRequest } from "./queryClient";

export interface User {
  id: string;
  username: string;
  email: string;
  name: string;
}

export const authApi = {
  login: () => {
    window.location.href = "/api/auth/microsoft";
  },

  logout: async () => {
    await apiRequest("POST", "/api/auth/logout");
  },

  getMe: async (): Promise<User | null> => {
    try {
      const res = await apiRequest("GET", "/api/auth/me");
      return await res.json();
    } catch (error) {
      return null;
    }
  },
};
