export const TAGS = [
  { name: "work", color: "bg-blue-500", label: "Work" },
  { name: "personal", color: "bg-green-500", label: "Personal" },
  { name: "important", color: "bg-red-500", label: "Important" },
] as const;

export const EMAIL_FOLDERS = [
  { name: "inbox", label: "Inbox", icon: "fas fa-inbox" },
  { name: "sent", label: "Sent", icon: "fas fa-paper-plane" },
  { name: "archive", label: "Archive", icon: "fas fa-archive" },
] as const;

export type TagType = typeof TAGS[number]["name"];
export type FolderType = typeof EMAIL_FOLDERS[number]["name"];
