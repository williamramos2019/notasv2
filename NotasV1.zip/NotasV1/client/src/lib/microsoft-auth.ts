import { PublicClientApplication, Configuration, AuthenticationResult } from "@azure/msal-browser";

const msalConfig: Configuration = {
  auth: {
    clientId: import.meta.env.VITE_MICROSOFT_CLIENT_ID || "",
    authority: `https://login.microsoftonline.com/${import.meta.env.VITE_MICROSOFT_TENANT_ID || "common"}`,
    redirectUri: window.location.origin + "/auth/callback",
  },
  cache: {
    cacheLocation: "localStorage",
    storeAuthStateInCookie: false,
  },
};

export const msalInstance = new PublicClientApplication(msalConfig);

export const loginRequest = {
  scopes: [
    "openid",
    "profile",
    "email",
    "Mail.Read",
    "Mail.ReadWrite",
    "offline_access"
  ],
};

export async function initializeMsal() {
  await msalInstance.initialize();
}

export async function signIn(): Promise<AuthenticationResult | null> {
  try {
    const response = await msalInstance.loginPopup(loginRequest);
    return response;
  } catch (error) {
    console.error("Sign in error:", error);
    return null;
  }
}

export async function signOut(): Promise<void> {
  try {
    await msalInstance.logoutPopup({
      postLogoutRedirectUri: window.location.origin,
    });
  } catch (error) {
    console.error("Sign out error:", error);
  }
}

export async function getAccessToken(): Promise<string | null> {
  try {
    const accounts = msalInstance.getAllAccounts();
    if (accounts.length === 0) {
      return null;
    }

    const silentRequest = {
      ...loginRequest,
      account: accounts[0],
    };

    const response = await msalInstance.acquireTokenSilent(silentRequest);
    return response.accessToken;
  } catch (error) {
    console.error("Token acquisition error:", error);
    return null;
  }
}
