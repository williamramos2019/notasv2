import { useState } from "react";
import Header from "@/components/header";
import Sidebar from "@/components/sidebar";
import NotesView from "@/components/notes-view";
import EmailModal from "@/components/email-modal";

export default function Home() {
  const [activeView, setActiveView] = useState<"notes" | "emails">("notes");
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  return (
    <div className="h-screen flex flex-col bg-background">
      <Header 
        searchQuery={searchQuery} 
        onSearchChange={setSearchQuery}
        data-testid="header-main"
      />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          activeView={activeView}
          onViewChange={setActiveView}
          selectedTag={selectedTag}
          onTagSelect={setSelectedTag}
          data-testid="sidebar-main"
        />
        
        <main className="flex-1 flex flex-col overflow-hidden">
          <NotesView
            selectedNoteId={selectedNoteId}
            onNoteSelect={setSelectedNoteId}
            searchQuery={searchQuery}
            selectedTag={selectedTag}
            data-testid="notes-view"
          />
        </main>
      </div>

      {activeView === "emails" && (
        <EmailModal 
          isOpen={true}
          onClose={() => setActiveView("notes")}
          data-testid="email-modal"
        />
      )}
    </div>
  );
}
