import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Login() {
  const { login, isLoggingIn } = useAuth();

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <i className="fas fa-sticky-note text-primary text-2xl"></i>
            <CardTitle className="text-2xl">NotasV1</CardTitle>
          </div>
          <CardDescription>
            Sign in with your Microsoft account to access your notes and emails
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button 
            onClick={login}
            disabled={isLoggingIn}
            className="w-full"
            size="lg"
            data-testid="button-microsoft-login"
          >
            {isLoggingIn ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                Signing in...
              </>
            ) : (
              <>
                <i className="fab fa-microsoft mr-2"></i>
                Sign in with Microsoft
              </>
            )}
          </Button>
          <p className="text-xs text-muted-foreground text-center mt-4">
            By signing in, you agree to our terms of service and privacy policy.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
