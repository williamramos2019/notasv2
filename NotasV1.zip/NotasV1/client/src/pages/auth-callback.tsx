import { useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

export default function AuthCallback() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    // The server handles the OAuth callback and redirects to dashboard
    // This component is just a fallback in case the redirect doesn't work
    const timer = setTimeout(() => {
      setLocation("/dashboard");
    }, 2000);

    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background">
      <Card className="w-full max-w-md mx-4">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center space-y-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <div className="text-center">
              <h1 className="text-xl font-semibold text-foreground">Authenticating...</h1>
              <p className="text-sm text-muted-foreground mt-2">
                Please wait while we complete your Microsoft authentication.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
