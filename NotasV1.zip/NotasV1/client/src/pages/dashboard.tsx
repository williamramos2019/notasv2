import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useNotes } from "@/hooks/use-notes";
import { Header } from "@/components/layout/header";
import { NotesSidebar } from "@/components/notes/notes-sidebar";
import { NotesList } from "@/components/notes/notes-list";
import { NoteEditor } from "@/components/notes/note-editor";
import { EmailModal } from "@/components/email/email-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, LogIn } from "lucide-react";
import type { Note } from "@shared/schema";

export default function Dashboard() {
  const { user, isLoading: authLoading, login, isLoggingIn } = useAuth();
  const { notes, createNote, updateNote, deleteNote, isLoading: notesLoading } = useNotes();
  const [activeView, setActiveView] = useState<"notes" | "emails">("notes");
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  // Handle theme toggle
  const handleToggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle("dark", !darkMode);
  };

  // Handle search
  const handleSearch = (query: string) => {
    // TODO: Implement search functionality
    console.log("Search:", query);
  };

  // Handle view changes
  const handleViewChange = (view: "notes" | "emails") => {
    setActiveView(view);
    if (view === "emails") {
      setIsEmailModalOpen(true);
    }
  };

  // Handle note operations
  const handleCreateNote = () => {
    const newNote = {
      title: "New Note",
      content: "",
      tags: [],
    };
    createNote(newNote);
  };

  const handleSelectNote = (note: Note) => {
    setSelectedNote(note);
  };

  const handleSaveNote = (noteData: { title: string; content: string; tags: string[] }) => {
    if (selectedNote) {
      updateNote({ id: selectedNote.id, ...noteData });
    } else {
      createNote(noteData);
    }
  };

  const handleDeleteNote = () => {
    if (selectedNote) {
      deleteNote(selectedNote.id);
      setSelectedNote(null);
    }
  };

  const handleToggleFavorite = (noteId: string) => {
    const note = notes.find(n => n.id === noteId);
    if (note) {
      updateNote({ id: noteId, isFavorite: !note.isFavorite });
    }
  };

  // Loading state
  if (authLoading) {
    return (
      <div className="h-full flex items-center justify-center bg-background">
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  // Authentication required
  if (!user) {
    return (
      <div className="h-full flex items-center justify-center bg-background">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                <i className="fab fa-microsoft text-primary text-2xl"></i>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Welcome to NotasV1</h1>
                <p className="text-muted-foreground mt-2">
                  Sign in with your Microsoft account to access your notes and emails.
                </p>
              </div>
              <Button 
                onClick={() => login()} 
                disabled={isLoggingIn}
                className="w-full"
                data-testid="button-microsoft-login"
              >
                {isLoggingIn ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  <>
                    <LogIn className="mr-2 h-4 w-4" />
                    Sign in with Microsoft
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <Header
        onSearch={handleSearch}
        darkMode={darkMode}
        onToggleDarkMode={handleToggleDarkMode}
      />
      
      <div className="flex flex-1 overflow-hidden">
        <NotesSidebar
          activeView={activeView}
          onViewChange={handleViewChange}
          onCreateNote={handleCreateNote}
          notesCount={notes.length}
          emailsCount={0} // TODO: Get actual email count
        />
        
        <div className="flex-1 flex overflow-hidden">
          <NotesList
            notes={notes}
            selectedNoteId={selectedNote?.id}
            onSelectNote={handleSelectNote}
            onToggleFavorite={handleToggleFavorite}
            onRefresh={() => window.location.reload()} // Simple refresh for now
            isLoading={notesLoading}
          />
          
          <NoteEditor
            note={selectedNote || undefined}
            onSave={handleSaveNote}
            onDelete={selectedNote ? handleDeleteNote : undefined}
          />
        </div>
      </div>

      <EmailModal
        isOpen={isEmailModalOpen}
        onClose={() => setIsEmailModalOpen(false)}
      />
    </div>
  );
}
